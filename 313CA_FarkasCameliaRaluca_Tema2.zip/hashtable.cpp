// Copyright 2017 FarkasCameliaRaluca
#include <hashtable.h>
#include <Graph.h>
#include <Hash.h>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

//  functie ce initializeaza matricea pentru senzori
//  avand distantele dintre 2 senzori
void initialize_sensors(int nrsens, Graph& sensors_distance)
{
	int sensors, i, j;

	for (i = 0; i < nrsens; ++i)
	{
		for (j = 0; j < nrsens; ++j)
		{
			if (i != j)
			{
				std::cin >> sensors;
				sensors_distance.add_to_edge(i, j, sensors);
			}
		}
	}
}

//  functie ce initializeaza hashtableul cu jucatorii
//  atribuindu-le numarul ordinea in care au fost cititi
void initialize_team(int no1, int no2, Hashtable<std::string, int>& players)
{
	int i;
	std::string name;

	for (i = 0; i < no1; ++i)
	{
		std::cin >> name;
		players.entry(name, i, 0);
	}
	for (i = 0; i < no2; ++i)
	{
		std::cin >> name;
		players.entry(name, i + no1, 1);
	}
}

//  functie ce se ocupa cu initializarea matricelor pentru distanta intre
//  senzori, cea pentru impuscaturile intre jucatori, cea pentru
//  senzorii unici activati si adaugarea punctajelor jucatorilor
void read(int& win0, int& win1, Graph& sensors_distance,
Graph& unique_sensors, Graph& shooting, Hashtable<std::string, int>& players)
{
	std::string joc_tag, s1, s2, s3;
	int s, playern, last_sen, playern2;
	double w_c0, w_c1;

	while (1)
	{
		std::cin >> s1;
		double m1, m2;

		//  in cazul in care s-a intalnit "END_CHAMPIONSHIP"
		//  jocul se incheie
		if (s1.find("END_CHAMPIONSHIP") != std::string::npos)
		{
				for (s = 0; s < players.what_size(); ++s)
				{
					//  se adauga punctele explorers din ultima runda
					players.add_distance(3*unique_sensors.no_per_line(s), s);
				}

				m1 = players.max_score();
				m2 = players.max_distance();

				//  in cazul in care scorul maxim este 0, se face dibision by 0
				// astfel ca se inlocuiesc numitorii cu 1
				if (players.max_score() == 0)
				{
					m1 = 1;
				}
				if (players.max_distance() == 0)
				{
					m2 = 1;
				}

				//  se calculeaza winning chance-urile dupa formula
				w_c0 = players.is_alive(0)*(players.total_score(0))/
				m1	+ (players.total_distance(0)/m2);
				w_c1 = players.is_alive(1)*(players.total_score(1))
				/m1 + (players.total_distance(1)/m2);

			//  se verifica winning chance-urile echipelor
			//  si in functie de ele se mareste punctajul echipei respective
			if (w_c0 > w_c1)
			{
				++win0;
			}
			else
			{
				++win1;
			}
			break;
		}

		//  in cazul citirii "JOC_X" se incepe alta runda
		if (s1.find("JOC_") != std::string::npos)
		{
			// se adauga punctajul oferit de senzorii activati
			// de fiecare jucator in runda anterioara
			for (s = 0; s < players.what_size(); ++s)
			{
				players.add_distance(3*unique_sensors.no_per_line(s), s);
			}

			//  daca prima echipa este in viata, aceasta a castigat
			// altfel, castiga cealalalta
			if (players.is_alive(0) != 0)
			{
				++win0;
			}
			else if (players.is_alive(1) != 0)
			{
				++win1;
			}
			//  se initializeaza noul joc si graphul de senzori activati
			players.new_game();

			unique_sensors.reinitialize();
		}
		else
		{
			//  daca primul argument este de forma "X:"
			//  se extrage numarul, se citeste numele jucatorului
			//  si i se adauga senzorul activat si distanta parcursa
			// daca a activat un alt senzor inainte in runda
			if (s1.find(":") != std::string::npos)
			{
				s1 = s1.substr(0, s1.size()-1);
				s = std::stoi(s1, nullptr);
				std::cin >> s2;

				playern = players.player_no(s2);

				unique_sensors.add_to_edge(playern, s, 1);

				last_sen = players.return_last_sensor(playern);

				if ((s > -1)&&(last_sen > -1)&&(players.is_alive(s)))
				{
					players.add_distance(
					sensors_distance.return_edge(last_sen, s), playern);
				}
				players.set_last_sensor(playern, s);
			}
			else
			{
				//  se citeste cel care impusca si cel impuscat
				//  se adauga punctajele aferente
				//  se adauga numarul de impuscaturi la matricea de dueluri
				std::cin >> s3 >> s2;

				players.shooting(s1, s2);

				playern = players.player_no(s1);

				playern2 = players.player_no(s2);

				shooting.add_to_edge(playern, playern2, 1);
			}
		}
	}
}

//  functie ce sorteaza pentru primele 2 top-uri descrescator
//  punctajele folosind shell sort
void shell_sort(std::vector<int>& points,
std::vector<std::string>&names, int size)
{
  int j;
  std::string temp1;

  for (int gap = size / 2; gap > 0; gap /= 2)
  {
    for (int i = gap; i < size; ++i)
    {
      int temp = points[i];

      temp1 = names[i];

      for (j = i; j >= gap && temp > points[j - gap]; j -= gap)
      {
        points[j] = points[j - gap];
        names[j] = names[j - gap];
      }

      points[j] = temp;
      names[j] = temp1;
    }
  }
}

//  functie ce sorteaza primele 2 topuri in mod alfabetic
//  al numelor (cand punctajele sunt egale)
void shell_sort1(std::vector<int>& points, std::vector<std::string>&names,
std::vector<std::string>&names1, int size)
{
  int j;
  std::string temp1, temp2;

for (int gap = size / 2; gap > 0; gap /= 2)
{
	for (int i = gap; i < size; ++i)
    {
      int temp = points[i];

      temp1 = names[i];

      temp2 = names1[i];

      for (j = i; j >= gap && temp > points[j - gap]; j -= gap)
      {
        points[j] = points[j - gap];
        names[j] = names[j - gap];
        names1[j] = names1[j - gap];
      }
      points[j] = temp;
      names[j] = temp1;
      names1[j] = temp2;
    }
  }
}

//  functie ce sorteaza al 3-lea top decrescator in functie de punctaj
void shell_sortn(std::vector<int>& points, std::vector<std::string>&names,
std::vector<std::string>&names1, int size)
{
  int j;
  std::string temp1, temp2;

  for (int gap = size / 2; gap > 0; gap /= 2)
  {
    for (int i = gap; i < size; ++i)
    {
      int temp = points[i];
      temp1 = names[i];
      temp2 = names1[i];

      for (j = i; j >= gap && temp == points[j - gap]
      && temp1 < names[j - gap]; j -= gap)
      {
        names[j] = names[j - gap];
        names1[j] = names1[j - gap];
      }
      names[j] = temp1;
      names1[j] = temp2;
    }
  }
}

//  functie ce ordoneaza al 3-lea top in mod alfabetic atunci cand punctajele
//  sunt egale
void shell_sortn1(std::vector<int>& points, std::vector<std::string>&names,
std::vector<std::string>&names1, int size)
{
  int j;
  std::string temp1, temp2;

  for (int gap = size / 2; gap > 0; gap /= 2)
  {
    for (int i = gap; i < size; ++i)
    {
      int temp = points[i];
      temp1 = names[i];
      temp2 = names1[i];
      for (j = i; j >= gap && temp == points[j - gap] &&
      temp1 == names[j - gap] && temp2 > names[j - gap]; j -= gap)
      {
        names1[j] = names1[j - gap];
      }
      names1[j] = temp2;
    }
  }
  for (j = 0; j < size - 1; ++j)
  {
  	if (points[j] == points[j+1] && names[j] == names[j + 1])
  	{
  		if (names1[j] > names1[j + 1])
  		{
  			temp1 = names1[j];
  			names1[j] = names1[j + 1];
  			names1[j + 1] = temp1;
  		}
  	}
  }
}

//  functie ce apeleaza functiile de sortare pentru topurile 1 si 2
void compare(std::vector<std::string> names, std::vector<int> points,
int lim, int size)
{
	int i, j, lim1 = lim;
	std::string aux1;

	shell_sort(points, names, size);

//  se numara elementele care au acelai punctaj ca ultima pozitie din top
	if (size > lim1)
	{
		while (points[lim - 1] == points[lim])
		{
			++lim1;

			if (lim1 == size)
			{
				break;
			}
		}
	}

//  se interschimba numele in mod alfabetic pentru punctaje egale
	for (i = 0; i < lim1 - 1; ++i)
	{
		for (j = i + 1; j < lim1; ++j)
		{
			if (points[i] == points[j])
		{
			if (names[i] > names[j])
			{
				aux1 = names[i];
				names[i] = names[j];
				names[j] = aux1;
			}
		}
		}
	}

//  se afiseaza topurile
	for (i = 0; i < lim; ++i)
	{
			std::cout << i+1 <<". " << names[i] << " " << points[i] << "p\n";
	}
	if (size > lim)
	{
		while (points[lim-1] == points[lim])
		{
			std::cout << lim+1 << ". " << names[lim] << " " <<
			points[lim] << "p\n";

			++lim;

			if (lim == size)
			{
				break;
			}
		}
	}
	std::cout << "\n";
}

//  functie ce proceseaza top-ul 3
void top_fire(std::vector<std::string> names, std::vector<std::string> names2,
std::vector<int> points, int lim, int size)
{
	int i, lim1 = lim;
	std::string aux1, aux2;

//  se foloseste prima functie de shell sort
	shell_sort1(points, names, names2, size);

//  se completeaza numarul de elemente cu cele egale de pe ultima pozitie
	if (size > lim1)
	{
		while (points[lim-1] == points[lim])
		{
			++lim1;

			if (lim1 == size)
			{
				break;
			}
		}
	}

//  se interschimba primul nume cu al doilea in ordine alfabetica
	for (i = 0; i < lim1; ++i)
	{
		if (names[i] > names2[i])
		{
			aux1 = names[i];
			names[i] = names2[i];
			names2[i] = aux1;
		}
	}

//  se ordoneaza alfabetic dupa primul nume cand punctajele sunt egale
//  si in cazul in care primul nume si punctajul sunt egale
	shell_sortn(points, names, names2, size);
	shell_sortn1(points, names, names2, size);

//  se afiseaza top-ul
	for (i = 0; i < lim; ++i)
	{
		std::cout << i+1 <<". " << names[i] << " - " << names2[i] <<
		" " << points[i] << "\n";
	}
	if (size > lim)
	{
		while(points[lim-1] == points[lim])
	{
		std::cout << lim+1 << ". " << names[lim] << " - " <<
		names2[lim] << " " << points[lim] << "\n";

		++lim;
	}
	}
	std::cout << "\n";
}

//  functie ce inglobeaza toate functiile de afisare precedente
void write_shooters(int&win0, int& win1, Graph& sensors_distance,
Graph& unique_sensors, Graph& shooting, Hashtable<std::string, int>& players)
{
	int i, j, size, nr;

	size = players.what_size();

	std::vector<std::string>names(size);
	std::vector<std::string>names1(size*(size-1)/2);
	std::vector<std::string>names2(size*(size-1)/2);
	std::vector<int>points(size);
	std::vector<int>points1(size*(size - 1)/2);
	std::vector<int>explorer(size);

	for (i = 0; i < size; ++i)
	{
		names[i] = players.what_player(i);
		points[i] = players.score(i);
		explorer[i] = players.dis(i);
	}
	int lim = std::min(5, size);

	std::cout << "I. Top shooters\n";

	compare(names, points, lim, size);

	std::cout << "II. Top explorers\n";

	compare(names, explorer, lim, size);

	nr = 0;

	for (i = 0; i < size; ++i)
	{
		for (j = 0; j < size; ++j)
		{
			if (j > i)
			{
				names1[nr] = players.what_player(i);
				names2[nr] = players.what_player(j);
				points1[nr] = shooting.return_edge(i, j) +
				shooting.return_edge(j, i);
				++nr;
			}
		}
	}
	std::cout << "III. Top fire exchange\n";

	lim = std::min(5, (size*(size-1)/2));
	top_fire(names1, names2, points1, lim, (size*(size-1)/2));

	std::cout << "IV. Final score\n";
	std::cout << win0-1 << " - " << win1 << "\n";
}
//  main-ul programului
int main()
{
	int nrsens, no1, no2;
	int win0 = 0, win1 = 0;

//  citirea numarului de senzori si apelarea functiei specifice
	std::cin >> nrsens;

//  declararea graph-ului pentru distantele dintre senzori
	Graph sensors_distance(nrsens, nrsens);

//  initializarea senzorilor
	initialize_sensors(nrsens, sensors_distance);

	std::cin >> no1 >> no2;

//  declararea graph-ului pentru senzorii unici activati
	Graph unique_sensors(no1+no2, nrsens);

//  declararea graph-ului pentru
	Graph shooting(no1+no2, no1+no2);

//  declararea hashtable-ului
	Hashtable<std::string, int> players(no1+no2, hash);

//  initializarea echipelor
	initialize_team(no1, no2, players);

//  apelarea functiei de citire de la stdin
	read(win0, win1, sensors_distance, unique_sensors, shooting, players);

//  apelarea functiei de scrierela stdout
	write_shooters(win0, win1, sensors_distance, unique_sensors,
	shooting, players);

	return 0;
}
