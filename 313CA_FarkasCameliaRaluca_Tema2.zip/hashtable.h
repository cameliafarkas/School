// Copyright 2017 FarkasCameliaRaluca
#ifndef __HASHTABLE__H
#define __HASHTABLE__H
#include <stdlib.h>
#include <Hash.h>
#include <string>
#include <iostream>
#include <fstream>

//  structura jucator ce are cheia numarul citirii sale
template<typename Tname, typename Tnumber>
    struct jucator {
        Tname name;
        Tnumber number;
        bool team;
        int distance;
        int points;
        int life;
        int last_sensor;

        //  constructorul ce initializeaza si campurile structurii
        jucator()
        {
            distance = 0;
            points = 0;
            number = -1;
            life = 2;
            last_sensor = -1;
        }
        //  destructorul default al structurii
        ~jucator(){}
    };

//  clasa Hashtable ce are o functie de hash asociata
template<typename Tname, typename Tnumber>
    class Hashtable
    {
        // elementele clasei Hashtable
     private:
            jucator<Tname, Tnumber>* H;
            int HMAX;
            int (*hash)(Tnumber);

     public:
            //  constructorul clasei Hashtable ce si initializeaza
            //  functia de hash si marimea hashtableului
            Hashtable(int hmax, int (*h)(Tnumber))
            {
                hash = h;

                HMAX = hmax;

                H = new jucator<Tname, Tnumber>[HMAX];
            }

            //  destructorul clasei Hashtable
            ~Hashtable()
            {
                delete[] H;
            }

            //  metoda ce initializeaza un membru al clasei
            void entry(Tname name, Tnumber number, bool nteam)
            {
                int idx = hash(number);

                H[idx].name = name;
                H[idx].number = number;
                H[idx].team = nteam;
            }

            //  metoda ce returneaza numarul de puncte pentru
            // shooting-uri ale unui jucator
            int score(Tnumber number)
            {
                int idx = hash(number);

                return H[idx].points;
            }

            //  metoda ce returneaza maximul de puncte pentru shooting
            // din intreaga competitie
            int max_score()
            {
                int idx;
                int nr = 0;

                for (idx = 0; idx < HMAX; ++idx)
                {
                    if (nr < score(idx))
                    {
                        nr = score(idx);
                    }
                }

                return nr;
            }

            //  metoda ce returneaza punctele pentru explorers
            //  ale unui jucator dupa indicele sau
            int dis(Tnumber number)
            {
                int idx = hash(number);

                return H[idx].distance;
            }

            //  metoda ce returneaza maximul de puncte pentru exploring
            //  din intreaga competitie
            int max_distance()
            {
                int idx;
                int nr = 0;

                for (idx = 0; idx < HMAX; ++idx)
                {
                    if (nr < dis(idx))
                    {
                        nr = dis(idx);
                    }
                }

                return nr;
            }

            //  metoda ce seteaza ultimul senzor activat de un jucator
            void set_last_sensor(Tnumber number, int s)
            {
                int idx = hash(number);

                H[idx].last_sensor = s;
            }

            //  metoda ce returneaza ultimul senzor activat de un jucator
            int return_last_sensor(Tnumber number)
            {
                int idx = hash(number);

                return H[idx].last_sensor;
            }

            //  metoda ce calculeaza punctele explorers pentru o echipa
            int total_distance(bool nteam)
            {
                int idx;
                int nr = 0;

                for (idx = 0; idx < HMAX; ++idx)
                {
                    if ((which_team(idx) == nteam)&&(is_alive(idx)))
                    {
                        nr += dis(idx);
                    }
                }
                return nr;
            }

            //  metoda ce calculeaza punctele de shooting pentru o echipa
            int total_score(bool nteam)
            {
                int idx;
                int nr = 0;

                for (idx = 0; idx < HMAX; ++idx)
                {
                    if ((which_team(idx) == nteam)&&(is_alive(idx)))
                    {
                        nr += score(idx);
                    }
                }

                return nr;
            }

            //  metoda ce returneaza echipa unui jucator
            bool which_team(Tnumber number)
            {
                int idx = hash(number);

                return H[idx].team;
            }

            //  metoda ce numara jucatorii in viata dintr-o echipa
            int is_alive(bool nteam)
            {
                int idx, nr = 0;

                for (idx = 0; idx < HMAX; ++idx)
                {
                    if ((H[idx].life > 0)&&(which_team(idx) == nteam))
                    {
                        ++nr;
                    }
                }
                return nr;
            }

            //  metoda ce returneaza marimea hahtable-ului
            int what_size()
            {
                return HMAX;
            }

            //  metoda ce returneaza numele unui jucator in functie de indice
            std::string what_player(Tnumber number)
            {
                int idx = hash(number);

                return H[idx].name;
            }

            //  metoda ce returneaza indicele unui jucator in functie de nume
            int player_no(Tname name)
            {
                int idx;

                for (idx = 0; idx < HMAX; ++idx)
                {
                    if (H[idx].name == name)
                    {
                        return idx;
                    }
                }
                return -1;
            }

            //  metoda ce scade viata jucatorului impuscat
            //  si aduna/scade puncte celui care a impuscat
            void shooting(Tname shooter, Tname shot)
            {
                int idx = player_no(shooter);
                int idx2 = player_no(shot);

                --H[idx2].life;

                if (which_team(idx) == which_team(idx2))
                {
                    H[idx].points -= 5;
                }
                else
                {
                    H[idx].points += 2;
                }
            }

            //  metoda ce reinitilizeaza jocul
            void new_game()
            {
                int idx;

                for (idx = 0; idx < HMAX; ++idx)
                {
                    H[idx].life = 2;
                    H[idx].last_sensor = -1;
                }
            }

            //  metoda ce adauga puncte pentru explorers unui jucator
            void add_distance(int dist, Tnumber number)
            {
                int idx = hash(number);

                H[idx].distance += dist;
            }
    };
#endif  //  __HASHTABLE__H
