// Copyright 2017 FarkasCameliaRaluca
#ifndef __HASH__H
#define __HASH__H
//  functia de hash este functia identitate
int hash(int nr)
{
    return nr;
}

#endif  //  __HASH__H
