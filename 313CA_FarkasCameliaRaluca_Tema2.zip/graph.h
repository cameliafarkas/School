// Copyright 2017 FarkasCameliaRaluca
#ifndef __GRAPH__H
#define __GRAPH__H
#include <stdio.h>
#include <iostream>
#include <vector>

//  este folosita doar matricea de adiacenta a unui graph
class Graph {
 private:
        int **adiacency_matrix;  //  este declarata ca un pointer dublu
        int size, size1;  // marimile matricei

 public:
     	//  constructorul clasei Graph ce initializeaza o matrice de s pe s2
         Graph(int s, int s2)
        {
        	size = s;
        	size1 = s2;

        	int i, j;

        	adiacency_matrix = new int*[size];

        	for(i = 0; i < size; ++i)
        	{
        		adiacency_matrix[i] = new int[size1];

        		for(j = 0; j < size1; ++j)
        		{
        			adiacency_matrix[i][j] = 0;
        		}
        	}
        }
        //  destructorul clasei graph
        ~Graph()
        {
        	int i;

        	for(i = 0; i < size; ++i)
        	{
        		delete[] adiacency_matrix[i];
        	}

        	delete[] adiacency_matrix;
        }
        //  metoda ce adauga o valoare pe o pozitie a matricei de adiacenta
        void add_to_edge(int src, int dst, int value)
        {
        	adiacency_matrix[src][dst] += value;
        }

        //  metoda ce scade valorea de pe o pozitie a matricei
        void remove_from_edge(int src, int dst, int value)
        {
        	adiacency_matrix[src][dst] -= value;
        }

        //  metoda ce returneaza valoarea gasita pe o pozitie a matricei
        int return_edge(int src, int dst)
        {
        	return adiacency_matrix[src][dst];
        }

        //  metoda ce numara elementele pozitive de pe o linie a matricei
        int no_per_line(int src)
        {
        	int nr = 0, i;

        	for (i = 0; i < size1; ++i)
        	{
        		if (return_edge(src, i) > 0)
        		{
        			++nr;
        		}
        	}
        	return nr;
        }

        //  metoda ce reinitializeaza cu 0 valorile matricei
        void reinitialize()
        {
        	int i, j;

        	for (i = 0; i < size; ++i)
        	{
        		for (j = 0; j < size1; ++j)
        		{
        			adiacency_matrix[i][j] = 0;
        		}
        	}
        }

        //  metoda ce afiseaza matricea (folosita pentru verificari)
        void disp()
        {
        	int i, j;

        	for (i = 0; i < size; ++i)
        	{
        		for (j = 0; j < size1; ++j)
        		{
        			std::cout << adiacency_matrix[i][j] << " ";
        		}
        		std::cout << "\n";
        	}
        }
};
#endif  //  __GRAPH__H
